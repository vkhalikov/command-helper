const windowsData = [
	{
		"command": "cd",
		"category": "Routing",
		"description": "Initialize a local Git repository"
	},
	
]

export default windowsData;