const npmData = [
	{
		"command": "npm install",
		"category": "Installing Packages",
		"description": "Install package"
	},
	
]

export default npmData;